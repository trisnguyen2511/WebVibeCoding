#!/usr/bin/env bash
# Chạy Jira CORS Proxy trên Mac / Linux
# Yêu cầu: Node.js >= 16  (kiểm tra: node --version)

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
node "$SCRIPT_DIR/jira-proxy.js"
