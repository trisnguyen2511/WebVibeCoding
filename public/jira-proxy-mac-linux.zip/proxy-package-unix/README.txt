====================================================
  JIRA CORS PROXY — Hướng dẫn sử dụng (Mac / Linux)
====================================================

YÊU CẦU
--------
  Node.js >= 16  (kiểm tra: node --version)
  Nếu chưa có: https://nodejs.org  hoặc  brew install node

BƯỚC 1: Cấu hình
-----------------
  Mở file config.json bằng bất kỳ text editor nào:

    "target" : URL Jira nội bộ (bắt buộc)
               Ví dụ: "https://jira.company.com"
                      "https://jira.company.com:8443"

    "token"  : Personal Access Token (PAT) của bạn (bắt buộc)
               Lấy tại: Jira → Profile → Personal Access Tokens

    "port"   : Port proxy trên máy (mặc định 8765, thường không cần đổi)

BƯỚC 2: Kết nối VPN
--------------------
  Đảm bảo VPN đang bật và truy cập được Jira.

BƯỚC 3: Chạy proxy
-------------------
  Mở Terminal, cd vào thư mục này, rồi chạy:

    bash start.sh

  Hoặc trực tiếp:

    node jira-proxy.js

  Màn hình sẽ hiện:
    ====================================================
      Jira CORS Proxy — Đang chạy!
    ====================================================
      Target : https://jira.company.com
      Port   : 8765
      Health : http://127.0.0.1:8765/health

BƯỚC 4: Kiểm tra kết nối
--------------------------
  Mở trình duyệt → http://127.0.0.1:8765/health
  Hoặc trong Terminal:  curl http://127.0.0.1:8765/health

  Nếu thấy {"status":"ok",...} → PROXY OK!

BƯỚC 5: Cấu hình Timeline App
-------------------------------
  Vào Timeline → Jira Integration → tab "Local Proxy"

    Port  : 8765  ← port trong config.json
    Token : <để trống — token đã nằm trong config.json>

  Bấm "Test Connection" → sẽ thấy "Connected as ..."

BƯỚC 6: Dừng proxy
-------------------
  Nhấn Ctrl+C trong Terminal đang chạy proxy.

====================================================
  THÔNG TIN KỸ THUẬT
====================================================
- Proxy chỉ lắng nghe trên localhost (127.0.0.1)
  → máy khác KHÔNG kết nối vào được, hoàn toàn an toàn.
- Token Jira: browser → proxy (local) → Jira nội bộ
  → không qua bất kỳ server bên ngoài nào.
- Strip các browser header trước khi forward (Origin,
  Referer, Sec-Fetch-*, User-Agent, ...) → Jira không
  phân biệt được với curl call thông thường.
- Bỏ qua lỗi SSL tự ký của Jira (tương đương curl -k).
====================================================
