====================================================
  JIRA CORS PROXY v2 — Hướng dẫn sử dụng
====================================================

BƯỚC 1: Cấu hình
----------------
Mở file config.json bằng Notepad và sửa:

  "target" : URL Jira nội bộ (bắt buộc)
             Ví dụ: "https://jira.company.com"
                    "https://jira.company.com:8443"

  "port"   : Port proxy chạy trên máy bạn (mặc định 8765)

BƯỚC 2: Kết nối VPN
-------------------
Đảm bảo VPN đang bật và có thể vào được Jira.

BƯỚC 3: Chạy proxy
-------------------
Double-click vào run.bat  (KHÔNG cần quyền Admin)

Cửa sổ sẽ hiện:
  ✓ Proxy đang chạy!
  Target : https://jira.company.com
  Port   : 8765

BƯỚC 4: Kiểm tra kết nối
--------------------------
Truy cập: http://127.0.0.1:8765/health
Nếu thấy {"status":"ok",...} → PROXY OK!

BƯỚC 5: Cấu hình Timeline App
------------------------------
Vào Timeline → Jira Integration → tab "Local Proxy"

  Port  : 8765  ← port trong config.json
  Token : <Personal Access Token của bạn>

Bấm "Test Connection" → sẽ thấy "Connected as ..."

BƯỚC 6: Dừng proxy
-------------------
Nhấn Ctrl+C trong cửa sổ proxy, hoặc đóng cửa sổ đi.

====================================================
  THAY ĐỔI TRONG v2
====================================================
- Chạy HTTP (không cần chấp nhận cert)
- Strip các browser header trước khi forward sang Jira
  (Origin, Referer, Sec-Fetch-*, User-Agent, ...)
  → Jira không thể phân biệt với direct curl call
- Bỏ qua lỗi SSL của Jira (tương đương curl -k)
====================================================
  LƯU Ý
====================================================
- Proxy chỉ lắng nghe trên localhost — máy khác không
  kết nối vào được, hoàn toàn an toàn.
- Token Jira đi thẳng từ browser → proxy → Jira,
  không qua bất kỳ server nào khác.
====================================================
