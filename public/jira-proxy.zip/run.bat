@echo off
echo ====================================================
echo   Jira CORS Proxy v2 - Khoi dong...
echo ====================================================
echo.
jira-proxy.exe
pause
